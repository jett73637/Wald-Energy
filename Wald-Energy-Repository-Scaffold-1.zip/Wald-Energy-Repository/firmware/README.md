# Firmware

Place the complete Arduino sketch here, for example:

`Wald_Energy_ESP32C3_v2.6.0.ino`

Keep credentials out of the public sketch. Include `private_config.h` locally, but do not upload it.
