# Release metadata

`latest.json` is a schema template only. It is not a valid update and must not be used to flash a device.

A real release must contain:
- a compiled ESP32-C3 `.bin` uploaded as a GitHub Release asset,
- the exact byte size,
- SHA-256 of the exact `.bin`,
- an Ed25519 signature over a documented canonical manifest,
- a matching public key embedded in the ESP firmware.

Never put the Ed25519 private signing key in this repository or on the ESP32.
