# Tools

Release preparation helpers will be added after the signing format and firmware build workflow are finalized.

Do not generate a release manifest manually until its canonical signature format is implemented in the firmware and release tooling.
